from setuptools import setup

if __name__ == '__main__':
  setup(name='trainer', packages=['trainer'], install_requires=['protobuf'])
