capture_tpu_profile \
        --tpu_name=$TPU_NAME \
        --logdir=$MODEL_DIR \
        --duration_ms=15000
